/*
=======================
03 - Price Notifications - PriceEmitter.js
=======================
Student ID:
Comment (Required):

=======================
*/
const EventEmitter = require('events');
class PriceEmitter extends EventEmitter {
	
	
	
}
module.exports = PriceEmitter;
