/*
=======================
04 - Bad Word Detection - BadWordEmitter.js
=======================
Student ID:
Comment (Required):

=======================
*/
const EventEmitter = require('events');
class BadWordEmitter extends EventEmitter{
	
	
	
}
module.exports = BadWordEmitter;