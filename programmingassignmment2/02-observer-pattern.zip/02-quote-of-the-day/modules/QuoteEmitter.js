/*
=======================
02 - Quote of the Day - QuoteEmitter.js
=======================
Student ID:
Comment (Required):

=======================
*/
const EventEmitter = require('events');
class QuoteEmitter extends EventEmitter {
	
	
	
}
module.exports = QuoteEmitter;